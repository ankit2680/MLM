import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision, json, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  phone: text("phone").notNull().unique(),
  referralId: text("referral_id").notNull().unique(),
  referredBy: integer("referred_by"),
  // Binary tree positioning
  parentId: integer("parent_id"),
  position: text("position"), // 'left' or 'right'
  // Account details
  registrationFee: doublePrecision("registration_fee").default(4),
  feePaid: boolean("fee_paid").default(false),
  wallet: doublePrecision("wallet").default(0),
  // Timestamps
  joinedAt: timestamp("joined_at").defaultNow(),
  isAdmin: boolean("is_admin").default(false),
});

// Transaction model
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // 'commission', 'withdrawal', 'registration'
  amount: doublePrecision("amount").notNull(),
  source: text("source"), // source of commission or destination of withdrawal
  description: text("description"), // detailed description of the transaction (optional)
  status: text("status").notNull(), // 'pending', 'completed', 'failed'
  createdAt: timestamp("created_at").defaultNow(),
});

// Withdrawal Request model
export const withdrawalRequests = pgTable("withdrawal_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: doublePrecision("amount").notNull(),
  bankDetails: jsonb("bank_details").notNull(),
  status: text("status").notNull().default("pending"), // 'pending', 'approved', 'rejected'
  createdAt: timestamp("created_at").defaultNow(),
  processedAt: timestamp("processed_at"),
});

// Schema validations
export const insertUserSchema = createInsertSchema(users)
  .omit({
    id: true,
    referralId: true,
    wallet: true,
    joinedAt: true,
    isAdmin: true,
    feePaid: true,
  })
  .extend({
    referralCode: z.string().min(4).max(20),
    confirmPassword: z.string().min(6),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

export const loginSchema = z.object({
  phone: z.string().min(10).max(15),
  password: z.string().min(6),
});

export const insertTransactionSchema = createInsertSchema(transactions)
  .omit({
    id: true,
    createdAt: true,
  });
  
// Fix omitting createdAt and id to avoid TypeScript issues

export const insertWithdrawalRequestSchema = createInsertSchema(withdrawalRequests).omit({
  id: true,
  createdAt: true,
  processedAt: true,
  status: true,
});

// Utility types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type WithdrawalRequest = typeof withdrawalRequests.$inferSelect;
export type LoginCredentials = z.infer<typeof loginSchema>;

// Binary tree node structure for the frontend
export interface TreeNode {
  id: number;
  name: string;
  initials: string;
  referralId: string;
  position: string | null;
  children: TreeNode[];
  isActive: boolean;
}

// Function to generate unique referral ID
export function generateReferralId(): string {
  const prefix = "BG";
  const randomDigits = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}${randomDigits}`;
}

// Function to calculate initials from name
export function getInitials(name: string): string {
  return name
    .split(' ')
    .map(part => part.charAt(0).toUpperCase())
    .join('')
    .substring(0, 2);
}
