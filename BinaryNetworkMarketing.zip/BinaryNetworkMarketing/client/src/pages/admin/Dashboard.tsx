import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/Header";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { fetchAdminStats, fetchAllUsers, fetchWithdrawals, processWithdrawal, generateTestData } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

export default function AdminDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  
  // Fetch admin stats
  const { 
    data: stats, 
    isLoading: statsLoading,
    refetch: refetchStats
  } = useQuery({
    queryKey: ['/api/admin/stats'],
    enabled: !!user?.isAdmin,
  });
  
  // Fetch all users
  const { 
    data: users, 
    isLoading: usersLoading,
    refetch: refetchUsers
  } = useQuery({
    queryKey: ['/api/admin/users'],
    enabled: !!user?.isAdmin && activeTab === "users",
  });
  
  // Fetch pending withdrawals
  const { 
    data: withdrawals, 
    isLoading: withdrawalsLoading,
    refetch: refetchWithdrawals
  } = useQuery({
    queryKey: ['/api/withdrawals', 'pending'],
    queryFn: () => fetchWithdrawals('pending'),
    enabled: !!user?.isAdmin && activeTab === "withdrawals",
  });
  
  // Handle withdrawal approval
  const handleWithdrawalAction = async (id: number, status: 'approved' | 'rejected') => {
    try {
      await processWithdrawal(id, status);
      toast({
        title: "Success",
        description: `Withdrawal request ${status}`,
      });
      refetchWithdrawals();
      refetchStats();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process withdrawal request",
        variant: "destructive",
      });
    }
  };
  
  // Generate test data for the network
  const handleGenerateTestData = async () => {
    try {
      await generateTestData();
      toast({
        title: "Success",
        description: "Test data generated successfully",
      });
      refetchStats();
      refetchUsers();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate test data",
        variant: "destructive",
      });
    }
  };
  
  if (!user?.isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center">Unauthorized</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-center">You don't have access to the admin dashboard.</p>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Admin Dashboard</h1>
            <p className="text-gray-500">Manage your MLM platform</p>
          </div>
          <Button 
            onClick={handleGenerateTestData} 
            className="bg-primary text-white hover:bg-primary/90"
          >
            Generate Test Data
          </Button>
        </div>
        
        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="withdrawals">Withdrawals</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview">
            {statsLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-pulse">
                {[...Array(4)].map((_, i) => (
                  <Card key={i} className="h-32"></Card>
                ))}
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Total Users</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">{stats?.totalUsers || 0}</p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Active Users</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">{stats?.activeUsers || 0}</p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Registration Fees</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">₹{stats?.totalRegistrationFees || 0}</p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Commissions Paid</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">₹{stats?.totalCommissionsPaid || 0}</p>
                    </CardContent>
                  </Card>
                </div>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Joins</CardTitle>
                    <CardDescription>New users who recently joined the platform</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Referral ID</TableHead>
                          <TableHead>Phone</TableHead>
                          <TableHead>Joined</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {stats?.recentJoins?.map((user: any) => (
                          <TableRow key={user.id}>
                            <TableCell>{user.name}</TableCell>
                            <TableCell>{user.referralId}</TableCell>
                            <TableCell>{user.phone}</TableCell>
                            <TableCell>{new Date(user.joinedAt).toLocaleDateString()}</TableCell>
                            <TableCell>
                              {user.feePaid ? (
                                <Badge variant="success" className="bg-green-100 text-green-800">
                                  Active
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
                                  Pending
                                </Badge>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>
          
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>All Users</CardTitle>
                <CardDescription>Manage all users in the system</CardDescription>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <div className="animate-pulse space-y-4">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="h-12 bg-gray-100 rounded"></div>
                    ))}
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Referral ID</TableHead>
                        <TableHead>Phone</TableHead>
                        <TableHead>Joined</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Wallet</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users?.filter((u: any) => !u.isAdmin).map((user: any) => (
                        <TableRow key={user.id}>
                          <TableCell>{user.name}</TableCell>
                          <TableCell>{user.referralId}</TableCell>
                          <TableCell>{user.phone}</TableCell>
                          <TableCell>{new Date(user.joinedAt).toLocaleDateString()}</TableCell>
                          <TableCell>
                            {user.feePaid ? (
                              <Badge variant="success" className="bg-green-100 text-green-800">
                                Active
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
                                Pending
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>₹{user.wallet}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="withdrawals">
            <Card>
              <CardHeader>
                <CardTitle>Pending Withdrawals</CardTitle>
                <CardDescription>Approve or reject withdrawal requests</CardDescription>
              </CardHeader>
              <CardContent>
                {withdrawalsLoading ? (
                  <div className="animate-pulse space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="h-16 bg-gray-100 rounded"></div>
                    ))}
                  </div>
                ) : withdrawals?.length === 0 ? (
                  <p className="text-center py-8 text-gray-500">No pending withdrawal requests</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User ID</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Bank Details</TableHead>
                        <TableHead>Requested On</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {withdrawals?.map((withdrawal: any) => (
                        <TableRow key={withdrawal.id}>
                          <TableCell>{withdrawal.userId}</TableCell>
                          <TableCell>₹{withdrawal.amount}</TableCell>
                          <TableCell>
                            <pre className="text-xs bg-gray-50 p-2 rounded overflow-x-auto">
                              {JSON.stringify(withdrawal.bankDetails, null, 2)}
                            </pre>
                          </TableCell>
                          <TableCell>{new Date(withdrawal.createdAt).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button 
                                size="sm" 
                                variant="outline"
                                className="bg-green-100 text-green-800 hover:bg-green-200"
                                onClick={() => handleWithdrawalAction(withdrawal.id, 'approved')}
                              >
                                Approve
                              </Button>
                              <Button 
                                size="sm" 
                                variant="outline"
                                className="bg-red-100 text-red-800 hover:bg-red-200"
                                onClick={() => handleWithdrawalAction(withdrawal.id, 'rejected')}
                              >
                                Reject
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
