import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/Header";
import UserInfo from "@/components/dashboard/UserInfo";
import StatCards from "@/components/dashboard/StatCards";
import BinaryTree from "@/components/ui/binary-tree";
import TransactionHistory from "@/components/dashboard/TransactionHistory";
import PayoutRules from "@/components/dashboard/PayoutRules";
import MobileNavigation from "@/components/dashboard/MobileNavigation";
import { fetchUserTree, fetchTransactions } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";
import { calculateNetworkSize, getLevels1to3Count, getBranchCounts } from "@/lib/utils/tree";
import { TreeNode } from "@shared/schema";

export default function Dashboard() {
  const { user, isLoading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState('home');

  // Fetch user tree
  const { 
    data: treeData, 
    isLoading: treeLoading,
    error: treeError 
  } = useQuery({
    queryKey: ['/api/users/tree'],
    enabled: !!user,
  });

  // Fetch transactions
  const { 
    data: transactions, 
    isLoading: txLoading,
    error: txError 
  } = useQuery({
    queryKey: ['/api/transactions'],
    enabled: !!user,
  });

  // Calculate metrics from tree
  const networkSize = treeData ? calculateNetworkSize(treeData) : 0;
  const branchCounts = treeData ? getBranchCounts(treeData) : { left: 0, right: 0 };
  const level1to3Count = treeData ? getLevels1to3Count(treeData) : 0;
  
  // Calculate recent payouts (commission earnings in the last 7 days)
  const recentPayouts = transactions 
    ? transactions
        .filter((tx: any) => 
          tx.type === 'commission' && 
          new Date(tx.createdAt) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
        )
        .reduce((sum: number, tx: any) => sum + tx.amount, 0)
    : 0;

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return null; // Let the Auth context handle redirect
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow container mx-auto px-4 py-6 pb-20 lg:pb-6">
        {/* User Info and Stats */}
        <div className="mb-6">
          <h2 className="text-xl font-medium text-gray-700 mb-4">Dashboard</h2>
          
          <UserInfo 
            name={user.name} 
            referralId={user.referralId}
            joinedAt={user.joinedAt}
          />
          
          <StatCards 
            earnings={user.wallet}
            directRecruits={`${branchCounts.left + branchCounts.right}/2`}
            leftRecruits={branchCounts.left}
            rightRecruits={branchCounts.right}
            networkSize={networkSize}
            level1to3Count={level1to3Count}
            recentPayouts={recentPayouts}
          />
        </div>

        {/* Binary Tree Visualization */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-medium text-gray-700">Your Network</h2>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-4 overflow-x-auto">
            {treeLoading ? (
              <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
              </div>
            ) : treeError ? (
              <div className="text-center text-red-500 py-8">
                Error loading network data. Please try again.
              </div>
            ) : (
              <BinaryTree tree={treeData as TreeNode} />
            )}
          </div>
        </div>

        {/* Transactions History */}
        <TransactionHistory 
          isLoading={txLoading} 
          error={txError as Error} 
          transactions={transactions}
        />

        {/* Payout Rules Information */}
        <PayoutRules />
      </main>

      <MobileNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
}
