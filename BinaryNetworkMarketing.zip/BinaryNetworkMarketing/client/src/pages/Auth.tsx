import { useState } from "react";
import { LoginForm } from "@/components/auth/LoginForm";
import { RegisterForm } from "@/components/auth/RegisterForm";

export default function Auth() {
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="bg-primary py-4">
        <div className="container mx-auto px-4">
          <h1 className="text-white text-2xl font-semibold text-center">BinaryGrowth</h1>
        </div>
      </header>

      <div className="flex-grow flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-white rounded-lg shadow-md overflow-hidden">
          {/* Tabs */}
          <div className="flex border-b border-gray-200">
            <button 
              className={`flex-1 py-3 font-medium text-center transition-colors ${
                activeTab === 'login' 
                  ? 'text-primary border-b-2 border-primary' 
                  : 'text-gray-500 hover:text-primary'
              }`}
              onClick={() => setActiveTab('login')}
            >
              Login
            </button>
            <button 
              className={`flex-1 py-3 font-medium text-center transition-colors ${
                activeTab === 'register' 
                  ? 'text-primary border-b-2 border-primary' 
                  : 'text-gray-500 hover:text-primary'
              }`}
              onClick={() => setActiveTab('register')}
            >
              Register
            </button>
          </div>

          {/* Forms */}
          <div className="p-6">
            {activeTab === 'login' ? <LoginForm /> : <RegisterForm />}
          </div>
        </div>
      </div>

      <footer className="py-4 bg-white border-t border-gray-200">
        <div className="container mx-auto px-4 text-center text-xs text-gray-400">
          <p>© {new Date().getFullYear()} BinaryGrowth. All rights reserved.</p>
          <p className="mt-1">By using this platform, you agree to our Terms of Service and Privacy Policy.</p>
        </div>
      </footer>
    </div>
  );
}
