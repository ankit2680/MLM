import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Bell, User, Settings, LogOut, LayoutDashboard, Shield } from "lucide-react";
import { getInitials } from "@/lib/utils/tree";
import { Link } from "wouter";

export default function Header() {
  const { user, logout } = useAuth();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  
  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleLogout = async () => {
    await logout();
    setIsDropdownOpen(false);
  };

  return (
    <header className="bg-primary shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-3">
          <div className="flex items-center">
            <Link href="/" className="text-white text-xl font-semibold hover:text-white/90">BinaryGrowth</Link>
            
            <div className="flex ml-6 space-x-4">
              {user?.isAdmin ? (
                <>
                  <Link href="/dashboard" className="text-white hover:text-white/90 flex items-center">
                    <LayoutDashboard className="h-4 w-4 mr-1" />
                    <span className="hidden md:inline">Dashboard</span>
                  </Link>
                  <Link href="/admin" className="text-white hover:text-white/90 flex items-center">
                    <Shield className="h-4 w-4 mr-1" />
                    <span className="hidden md:inline">Admin</span>
                  </Link>
                </>
              ) : null}
            </div>
          </div>
          <div className="flex items-center">
            <button 
              type="button" 
              className="text-white p-2 rounded-full hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-white"
            >
              <Bell className="h-5 w-5" />
            </button>
            <div className="ml-3 relative">
              <button 
                type="button" 
                className="flex items-center text-white text-sm focus:outline-none focus:ring-2 focus:ring-white" 
                onClick={toggleDropdown}
              >
                <span className="mr-2 hidden sm:inline-block">{user?.name}</span>
                <div className="h-8 w-8 rounded-full bg-primary-dark flex items-center justify-center text-white">
                  <span>{user ? getInitials(user.name) : "U"}</span>
                </div>
              </button>
              
              {/* User dropdown menu */}
              {isDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
                  <a 
                    href="#profile" 
                    className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    onClick={() => setIsDropdownOpen(false)}
                  >
                    <User className="h-4 w-4 mr-2" />
                    Your Profile
                  </a>
                  <a 
                    href="#settings" 
                    className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    onClick={() => setIsDropdownOpen(false)}
                  >
                    <Settings className="h-4 w-4 mr-2" />
                    Settings
                  </a>
                  <div className="border-t border-gray-200"></div>
                  <button 
                    className="w-full text-left flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    onClick={handleLogout}
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
