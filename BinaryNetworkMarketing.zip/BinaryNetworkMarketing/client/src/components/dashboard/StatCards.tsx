import { 
  IndianRupee, 
  Users, 
  NetworkIcon, 
  HandCoins 
} from 'lucide-react';

interface StatCardsProps {
  earnings: number;
  directRecruits: string;
  leftRecruits: number;
  rightRecruits: number;
  networkSize: number;
  level1to3Count: number;
  recentPayouts: number;
}

export default function StatCards({
  earnings,
  directRecruits,
  leftRecruits,
  rightRecruits,
  networkSize,
  level1to3Count,
  recentPayouts,
}: StatCardsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* Earnings Card */}
      <div className="bg-white rounded-lg shadow-sm p-4">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm text-gray-500">Total Earnings</p>
            <h3 className="text-2xl font-medium text-gray-700 mt-1">₹{earnings}</h3>
          </div>
          <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center text-green-600">
            <IndianRupee className="h-5 w-5" />
          </div>
        </div>
        <div className="mt-4">
          <a href="#wallet" className="text-xs text-primary flex items-center">
            View Wallet <span className="ml-1">→</span>
          </a>
        </div>
      </div>

      {/* Direct Recruits Card */}
      <div className="bg-white rounded-lg shadow-sm p-4">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm text-gray-500">Direct Recruits</p>
            <h3 className="text-2xl font-medium text-gray-700 mt-1">{directRecruits}</h3>
          </div>
          <div className="h-10 w-10 rounded-full bg-primary bg-opacity-10 flex items-center justify-center text-primary">
            <Users className="h-5 w-5" />
          </div>
        </div>
        <div className="flex items-center mt-4">
          <div className="flex-1">
            <p className="text-xs text-gray-500">Left</p>
            <p className="text-sm font-medium">{leftRecruits}</p>
          </div>
          <div className="flex-1">
            <p className="text-xs text-gray-500">Right</p>
            <p className="text-sm font-medium">{rightRecruits}</p>
          </div>
        </div>
      </div>

      {/* Network Size Card */}
      <div className="bg-white rounded-lg shadow-sm p-4">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm text-gray-500">Network Size</p>
            <h3 className="text-2xl font-medium text-gray-700 mt-1">{networkSize}</h3>
          </div>
          <div className="h-10 w-10 rounded-full bg-cyan-100 flex items-center justify-center text-cyan-600">
            <NetworkIcon className="h-5 w-5" />
          </div>
        </div>
        <div className="flex items-center mt-4">
          <div className="flex-1">
            <p className="text-xs text-gray-500">L1-3 Members</p>
            <p className="text-sm font-medium">{level1to3Count}</p>
          </div>
          <div className="flex-1">
            <p className="text-xs text-gray-500">Growth</p>
            <p className="text-sm font-medium text-green-600">+{Math.min(2, networkSize)} this week</p>
          </div>
        </div>
      </div>

      {/* Payouts Card */}
      <div className="bg-white rounded-lg shadow-sm p-4">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm text-gray-500">Recent Payouts</p>
            <h3 className="text-2xl font-medium text-gray-700 mt-1">₹{recentPayouts}</h3>
          </div>
          <div className="h-10 w-10 rounded-full bg-pink-100 flex items-center justify-center text-pink-600">
            <HandCoins className="h-5 w-5" />
          </div>
        </div>
        <div className="mt-4">
          <a href="#transactions" className="text-xs text-primary flex items-center">
            View Transactions <span className="ml-1">→</span>
          </a>
        </div>
      </div>
    </div>
  );
}
