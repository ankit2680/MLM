import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ArrowDownCircle, ArrowUpCircle } from "lucide-react";

interface TransactionHistoryProps {
  isLoading: boolean;
  error: Error | null;
  transactions: any[] | null;
}

export default function TransactionHistory({
  isLoading,
  error,
  transactions,
}: TransactionHistoryProps) {
  if (isLoading) {
    return (
      <div className="mb-6">
        <h2 className="text-xl font-medium text-gray-700 mb-4">Earnings & Transactions</h2>
        <div className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="space-y-3">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-12 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="mb-6">
        <h2 className="text-xl font-medium text-gray-700 mb-4">Earnings & Transactions</h2>
        <div className="bg-white rounded-lg shadow-sm p-6 text-center">
          <p className="text-red-500">Error loading transactions: {error.message}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-6">
      <h2 className="text-xl font-medium text-gray-700 mb-4">Earnings & Transactions</h2>
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h3 className="font-medium">Recent Transactions</h3>
            <button className="text-primary text-sm">View All</button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Transaction</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Source</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions && transactions.length > 0 ? (
                transactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell>
                      <div className="flex items-center">
                        <div 
                          className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center ${
                            transaction.type === 'commission'
                              ? 'bg-green-100 text-green-600'
                              : 'bg-blue-100 text-blue-600'
                          }`}
                        >
                          {transaction.amount > 0 ? (
                            <ArrowDownCircle className="h-4 w-4" />
                          ) : (
                            <ArrowUpCircle className="h-4 w-4" />
                          )}
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-700">
                            {transaction.type === 'commission' 
                              ? 'Commission Earned' 
                              : transaction.type === 'withdrawal'
                                ? 'Withdrawal'
                                : 'Registration Fee'}
                          </div>
                          <div className="text-xs text-gray-500">
                            {transaction.type === 'commission' 
                              ? 'Level 3 payout' 
                              : transaction.type === 'withdrawal'
                                ? 'To bank account'
                                : 'Account activation'}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className={`text-sm font-medium ${
                      transaction.amount > 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {transaction.amount > 0 ? '+' : ''}{transaction.amount.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {transaction.source}
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {new Date(transaction.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={`${
                          transaction.status === 'completed'
                            ? 'bg-green-100 text-green-800'
                            : transaction.status === 'pending'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-6 text-gray-500">
                    No transactions yet
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {transactions && transactions.length > 0 && (
          <div className="px-4 py-3 bg-gray-50 flex justify-between items-center">
            <div className="text-sm text-gray-500">
              Showing {Math.min(transactions.length, 10)} of {transactions.length} transactions
            </div>
            <div className="flex items-center space-x-2">
              <button className="px-2 py-1 border border-gray-300 rounded-md bg-white text-sm text-gray-600 disabled:opacity-50" disabled>
                Previous
              </button>
              <button className="px-2 py-1 border border-gray-300 rounded-md bg-white text-sm text-gray-600">
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
