export default function PayoutRules() {
  return (
    <div className="mb-6">
      <div className="bg-white rounded-lg shadow-sm p-4">
        <h3 className="font-medium text-gray-700 mb-2">How Commissions Work</h3>
        <div className="flex flex-col md:flex-row mb-4">
          <div className="flex-1 mb-4 md:mb-0 md:mr-4">
            <div className="rounded-lg bg-primary bg-opacity-5 p-3 h-full">
              <h4 className="text-primary font-medium text-sm mb-2">Multi-Level Commission Structure</h4>
              <p className="text-xs text-gray-600 mb-2">
                <span className="font-semibold">Level 2 Completion:</span> ₹4 when direct referrals complete their pairs
              </p>
              <p className="text-xs text-gray-600 mb-2">
                <span className="font-semibold">Level 3+:</span> ₹1 per member
              </p>
              <div className="text-xs text-gray-500">
                Example: If A refers B & C, when B refers D and E, and C refers F and G, then A will earn ₹4.
              </div>
            </div>
          </div>
          <div className="flex-1">
            <div className="rounded-lg bg-cyan-500 bg-opacity-5 p-3 h-full">
              <h4 className="text-cyan-600 font-medium text-sm mb-2">Binary Tree Structure</h4>
              <p className="text-xs text-gray-600 mb-2">
                Each member can have maximum 2 direct referrals - one on the left branch and one on the right branch.
              </p>
              <div className="text-xs text-gray-500">
                To maximize your earnings, try to maintain a balanced tree by referring new members to both left and right branches.
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row">
          <div className="flex-1 mb-4 md:mb-0 md:mr-4">
            <div className="rounded-lg bg-amber-500 bg-opacity-5 p-3 h-full">
              <h4 className="text-amber-600 font-medium text-sm mb-2">Withdrawal Rules</h4>
              <p className="text-xs text-gray-600 mb-2">
                <span className="font-semibold">Minimum withdrawal:</span> ₹20
              </p>
              <p className="text-xs text-gray-600 mb-2">
                Withdrawals are processed by admin and credited to your account.
              </p>
              <div className="text-xs text-gray-500">
                To request a withdrawal, go to the Withdrawals tab and enter the amount and your bank details.
              </div>
              <div className="text-xs text-red-500 mt-2 font-medium">
                Important: MLM investments carry financial risks. Please invest responsibly.
              </div>
            </div>
          </div>
          <div className="flex-1">
            <div className="rounded-lg bg-emerald-500 bg-opacity-5 p-3 h-full">
              <h4 className="text-emerald-600 font-medium text-sm mb-2">Continuous Earnings</h4>
              <p className="text-xs text-gray-600 mb-2">
                As your network grows deeper, you continue to earn commissions from new members.
              </p>
              <div className="text-xs text-gray-500">
                The commission structure extends throughout all levels of your network, helping you build passive income over time.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
