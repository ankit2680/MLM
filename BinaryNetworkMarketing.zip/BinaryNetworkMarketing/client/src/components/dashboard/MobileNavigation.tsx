import { Home, Network, Wallet, User } from "lucide-react";

interface MobileNavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function MobileNavigation({ activeTab, setActiveTab }: MobileNavigationProps) {
  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-10">
      <div className="flex justify-around">
        <a 
          href="#dashboard" 
          className={`flex flex-col items-center py-2 flex-1 ${
            activeTab === 'home' ? 'text-primary' : 'text-gray-500'
          }`}
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('home');
          }}
        >
          <Home className="h-5 w-5" />
          <span className="text-xs mt-1">Home</span>
        </a>
        <a 
          href="#network" 
          className={`flex flex-col items-center py-2 flex-1 ${
            activeTab === 'network' ? 'text-primary' : 'text-gray-500'
          }`}
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('network');
          }}
        >
          <Network className="h-5 w-5" />
          <span className="text-xs mt-1">Network</span>
        </a>
        <a 
          href="#wallet" 
          className={`flex flex-col items-center py-2 flex-1 ${
            activeTab === 'wallet' ? 'text-primary' : 'text-gray-500'
          }`}
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('wallet');
          }}
        >
          <Wallet className="h-5 w-5" />
          <span className="text-xs mt-1">Wallet</span>
        </a>
        <a 
          href="#profile" 
          className={`flex flex-col items-center py-2 flex-1 ${
            activeTab === 'profile' ? 'text-primary' : 'text-gray-500'
          }`}
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('profile');
          }}
        >
          <User className="h-5 w-5" />
          <span className="text-xs mt-1">Profile</span>
        </a>
      </div>
    </div>
  );
}
