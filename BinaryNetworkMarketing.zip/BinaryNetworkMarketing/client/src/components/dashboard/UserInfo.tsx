import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Share2, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getInitials } from "@/lib/utils/tree";

interface UserInfoProps {
  name: string;
  referralId: string;
  joinedAt: string;
}

export default function UserInfo({ name, referralId, joinedAt }: UserInfoProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      day: 'numeric', 
      month: 'short', 
      year: 'numeric' 
    });
  };
  
  const copyReferralId = () => {
    navigator.clipboard.writeText(referralId);
    setCopied(true);
    toast({
      title: "Copied!",
      description: "Referral ID copied to clipboard",
    });
    
    setTimeout(() => setCopied(false), 2000);
  };
  
  const shareReferral = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Join BinaryGrowth',
        text: `Join BinaryGrowth using my referral code: ${referralId}`,
        url: window.location.origin,
      }).catch((error) => {
        console.log('Error sharing', error);
      });
    } else {
      copyReferralId();
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
      <div className="flex flex-wrap items-center">
        <div className="mr-4">
          <div className="h-16 w-16 rounded-full bg-primary flex items-center justify-center text-white text-xl">
            <span>{getInitials(name)}</span>
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-lg font-medium text-gray-700">{name}</h3>
          <div className="flex flex-wrap items-center mt-1">
            <div className="flex items-center mr-4">
              <span className="text-sm font-medium text-gray-600">ID:</span>
              <span className="text-sm ml-1 text-primary">{referralId}</span>
              <button 
                className="ml-1 text-primary focus:outline-none" 
                title="Copy Referral ID"
                onClick={copyReferralId}
              >
                {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
              </button>
            </div>
            <div className="flex items-center">
              <span className="text-sm font-medium text-gray-600">Joined:</span>
              <span className="text-sm ml-1 text-gray-500">{formatDate(joinedAt)}</span>
            </div>
          </div>
        </div>
        <div className="mt-4 sm:mt-0">
          <Button 
            variant="default" 
            className="bg-primary text-white py-1.5 px-3 rounded-md text-sm flex items-center"
            onClick={shareReferral}
          >
            <Share2 className="h-4 w-4 mr-1" /> Share Referral
          </Button>
        </div>
      </div>
    </div>
  );
}
