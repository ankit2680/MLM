import { TreeNode } from "@shared/schema";
import { User, Info } from "lucide-react";
import { useState } from "react";

interface TreeNodeProps {
  node: TreeNode;
  isRoot: boolean;
  isSmall?: boolean;
}

export default function TreeNodeComponent({ node, isRoot, isSmall = false }: TreeNodeProps) {
  const [showDetails, setShowDetails] = useState(false);
  
  // Empty node
  if (node.id < 0) {
    return (
      <div className="relative">
        <div className={`${isSmall ? 'h-12 w-12' : 'h-14 w-14'} rounded-full bg-gray-200 flex items-center justify-center text-gray-400 border-2 border-white shadow-md cursor-pointer`}>
          <span className="text-sm">+</span>
        </div>
        <div className="text-xs text-gray-500 mt-1 text-center">Empty</div>
      </div>
    );
  }
  
  // Active node styling
  const bgColor = isRoot ? 'bg-primary' : (node.isActive ? 'bg-cyan-500' : 'bg-gray-200');
  const textColor = isRoot || node.isActive ? 'text-white' : 'text-gray-500';
  
  return (
    <div className="relative group">
      <div 
        className={`${isSmall ? 'h-12 w-12' : 'h-14 w-14'} rounded-full ${bgColor} flex items-center justify-center ${textColor} border-2 border-white shadow-md cursor-pointer transition-transform hover:scale-110`}
        onClick={() => setShowDetails(!showDetails)}
      >
        <span>{node.initials}</span>
      </div>
      
      {node.isActive && (
        <div className="absolute -bottom-1 -right-1 h-5 w-5 rounded-full bg-white flex items-center justify-center border border-primary text-primary text-xs">
          <User className="h-3 w-3" />
        </div>
      )}
      
      {/* User details tooltip */}
      {showDetails && (
        <div className="absolute z-10 bg-white rounded-md shadow-lg p-3 w-48 text-sm -left-16 mt-2">
          <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-4 h-4 rotate-45 bg-white"></div>
          <div className="font-medium text-gray-800 mb-1">{node.name}</div>
          <div className="text-xs text-gray-600 mb-1">
            <span className="font-medium">ID:</span> {node.referralId}
          </div>
          <div className="text-xs text-gray-600 mb-1">
            <span className="font-medium">Position:</span> {node.position || 'Root'}
          </div>
          <div className="text-xs text-gray-600">
            <span className="font-medium">Status:</span> {node.isActive ? 'Active' : 'Pending'}
          </div>
        </div>
      )}
      
      {/* Always show name below for better visibility */}
      <div className="text-xs text-gray-700 mt-1 text-center font-medium">
        {isSmall ? node.initials : (node.name.length > 12 ? node.name.substring(0, 10) + '...' : node.name)}
      </div>
      
      {/* Hover info indicator */}
      <div className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-gray-100 flex items-center justify-center border border-gray-300 text-gray-500 text-xs">
        <Info className="h-3 w-3" />
      </div>
    </div>
  );
}
