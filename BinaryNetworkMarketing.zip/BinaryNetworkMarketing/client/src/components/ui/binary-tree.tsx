import { TreeNode } from "@shared/schema";
import TreeNodeComponent from "./tree-node";
import { useState, useCallback, useMemo } from "react";
import { ChevronDown, ChevronUp, ZoomIn, ZoomOut, Layers, RefreshCw } from "lucide-react";
import { Button } from "./button";
import { Skeleton } from "./skeleton";
import { useQuery } from "@tanstack/react-query";
import { fetchUserTree } from "@/lib/api";
import { QueryFunction } from "@tanstack/react-query";

// For type safety
type TreeNodeResponse = TreeNode;

interface BinaryTreeProps {
  tree: TreeNode | null;
}

// Function to count total nodes at each level in the tree
const countNodesPerLevel = (node: TreeNode | null, results: number[] = [], level = 0): number[] => {
  if (!node) return results;
  
  // Ensure the results array has a slot for the current level
  if (results.length <= level) {
    results[level] = 0;
  }
  
  // Count this node
  results[level]++;
  
  // Recursively count children
  if (node.children && node.children.length > 0) {
    node.children.forEach(child => {
      countNodesPerLevel(child, results, level + 1);
    });
  }
  
  return results;
};

export default function BinaryTree({ tree }: BinaryTreeProps) {
  const [showLevel3, setShowLevel3] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [maxLevel, setMaxLevel] = useState(3);
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Calculate if the tree is getting large (might need pagination)
  const [currentPage, setCurrentPage] = useState(1);
  const nodesPerPage = 20; // How many nodes to show per page for very large trees
  
  // Fetch tree data with the current max level
  const { data: extendedTree, isLoading, refetch } = useQuery<TreeNodeResponse | null>({
    queryKey: ['/api/users/tree', maxLevel],
    queryFn: async () => await fetchUserTree(maxLevel),
    enabled: maxLevel > 3, // Only fetch if we're looking beyond the default 3 levels
    initialData: tree // Use the provided tree as initial data
  });
  
  // Use the extended tree if available, otherwise use the provided tree
  const currentTree = extendedTree || tree;
  
  // Handle refreshing tree data to show more levels
  const handleLoadMoreLevels = useCallback(() => {
    setIsRefreshing(true);
    setMaxLevel(prev => prev + 2); // Add 2 more levels
    refetch().finally(() => setIsRefreshing(false));
  }, [refetch]);
  
  // Count nodes at each level
  const nodesPerLevel = useMemo(() => {
    if (!currentTree) return [];
    return countNodesPerLevel(currentTree);
  }, [currentTree]);
  
  // Calculate if we have any level 3 nodes to show
  const hasLevel3Nodes = useMemo(() => {
    if (!currentTree) return false;
    return currentTree.children.some((child: TreeNode) => 
      child.children && child.children.some((grandChild: TreeNode) => 
        grandChild.children && grandChild.children.length > 0
      )
    );
  }, [currentTree]);
  
  // Calculate total nodes in the network
  const totalNodes = useMemo(() => {
    return nodesPerLevel.reduce((sum, count) => sum + count, 0);
  }, [nodesPerLevel]);
  
  // Check if the tree is large enough to need pagination
  const isLargeTree = totalNodes > 30;
  
  // Function to get paginated trees for large networks
  const getPaginatedData = useCallback(() => {
    if (!isLargeTree || !currentTree) return { paginatedTree: currentTree, totalPages: 1 };
    
    // For simplicity in this demo, we'll just handle pagination for level 3+ nodes
    // In a production app, you'd implement more sophisticated tree pagination
    
    const totalPages = Math.ceil(totalNodes / nodesPerPage);
    
    // Return the current tree for now, but in a full implementation
    // you would slice the appropriate section of the tree
    return {
      paginatedTree: currentTree,
      totalPages
    };
  }, [currentTree, isLargeTree, totalNodes, nodesPerPage]);
  
  const { paginatedTree, totalPages } = getPaginatedData();

  if (!currentTree) {
    return <p className="text-center py-8">No tree data available.</p>;
  }
  
  return (
    <div className="relative">
      {/* Tree Controls */}
      <div className="mb-4 p-3 bg-gray-50 rounded-lg shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => setZoomLevel(Math.min(zoomLevel + 0.1, 1.5))}
              disabled={zoomLevel >= 1.5}
            >
              <ZoomIn className="h-4 w-4 mr-1" /> Zoom In
            </Button>
            
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => setZoomLevel(Math.max(zoomLevel - 0.1, 0.7))}
              disabled={zoomLevel <= 0.7}
            >
              <ZoomOut className="h-4 w-4 mr-1" /> Zoom Out
            </Button>
            
            {hasLevel3Nodes && (
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => setShowLevel3(!showLevel3)}
              >
                {showLevel3 ? (
                  <>
                    <ChevronUp className="h-4 w-4 mr-1" />
                    Hide Level 3
                  </>
                ) : (
                  <>
                    <ChevronDown className="h-4 w-4 mr-1" />
                    Show Level 3
                  </>
                )}
              </Button>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              size="sm"
              variant="outline"
              onClick={handleLoadMoreLevels}
              disabled={isRefreshing || isLoading || maxLevel >= 8}
            >
              {isRefreshing ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-1 animate-spin" />
                  Loading...
                </>
              ) : (
                <>
                  <Layers className="h-4 w-4 mr-1" />
                  Load More Levels
                </>
              )}
            </Button>
          </div>
        </div>
        
        <div className="mt-3 text-sm text-gray-600">
          <p className="flex items-center">
            <Layers className="h-4 w-4 mr-1 text-primary" />
            <span>Your network has {totalNodes} member{totalNodes !== 1 ? 's' : ''} across {nodesPerLevel.length} level{nodesPerLevel.length !== 1 ? 's' : ''}</span>
          </p>
          
          {/* Pagination controls for large networks */}
          {isLargeTree && totalPages > 1 && (
            <div className="flex items-center justify-center space-x-2 mt-2">
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
                disabled={currentPage === 1}
              >
                Previous
              </Button>
              <span className="text-sm">
                Page {currentPage} of {totalPages}
              </span>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                Next
              </Button>
            </div>
          )}
        </div>
      </div>
      
      {/* Instructions */}
      <div className="mb-4 text-sm text-gray-600 bg-gray-50 p-2 rounded-md">
        <p>Click on any network member to view their details. You can only see details of members below you in the hierarchy.</p>
      </div>
      
      {isLoading && maxLevel > 3 ? (
        <div className="my-8 space-y-4">
          <Skeleton className="h-16 w-16 rounded-full mx-auto" />
          <div className="flex justify-center space-x-24">
            <Skeleton className="h-12 w-12 rounded-full" />
            <Skeleton className="h-12 w-12 rounded-full" />
          </div>
          <div className="flex justify-between px-10">
            <Skeleton className="h-10 w-10 rounded-full" />
            <Skeleton className="h-10 w-10 rounded-full" />
            <Skeleton className="h-10 w-10 rounded-full" />
            <Skeleton className="h-10 w-10 rounded-full" />
          </div>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <div 
            className="min-w-[600px] flex flex-col items-center"
            style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'top center' }}
          >
            {/* Root Node (Level 0) */}
            <div className="flex justify-center mb-6">
              <TreeNodeComponent 
                node={currentTree} 
                isRoot={true}
              />
            </div>
            
            {/* Connecting Lines from Root to Level 1 */}
            <div className="flex justify-center">
              <div className="flex flex-col items-center">
                <div className="w-[2px] h-8 bg-gray-300"></div>
                <div className="w-40 h-[2px] bg-gray-300 flex items-center justify-center">
                  <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
                </div>
                <div className="flex justify-between w-40">
                  <div className="w-[2px] h-8 bg-gray-300"></div>
                  <div className="w-[2px] h-8 bg-gray-300"></div>
                </div>
              </div>
            </div>
            
            {/* Level 1 - Direct Recruits */}
            <div className="flex justify-center space-x-40 mb-8">
              {currentTree.children.map((child: TreeNode, index: number) => (
                <div key={`child-${index}`} className="flex flex-col items-center">
                  <div className="mb-2 px-2 py-1 bg-primary bg-opacity-10 text-primary text-xs rounded-full">
                    {index === 0 ? 'Left Branch' : 'Right Branch'}
                  </div>
                  <TreeNodeComponent 
                    node={child} 
                    isRoot={false}
                  />
                </div>
              ))}
            </div>
            
            {/* Connecting Lines from Level 1 to Level 2 */}
            <div className="flex justify-center w-full mb-2">
              <div className="flex justify-between w-[600px]">
                {currentTree.children.map((child, childIndex) => (
                  <div key={`line-group-${childIndex}`} className="flex flex-col items-center mx-4">
                    <div className="w-[2px] h-8 bg-gray-300"></div>
                    <div className="w-40 h-[2px] bg-gray-300 flex items-center justify-center">
                      <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
                    </div>
                    <div className="flex justify-between w-40">
                      <div className="w-[2px] h-8 bg-gray-300"></div>
                      <div className="w-[2px] h-8 bg-gray-300"></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Level 2 */}
            <div className="flex justify-between w-full px-6 mb-10">
              {currentTree.children.map((child, childIndex) => (
                <div key={`child-branch-${childIndex}`} className="flex justify-between w-60">
                  {child.children.map((grandChild, grandChildIndex) => (
                    <div key={`grandchild-${childIndex}-${grandChildIndex}`} className="flex flex-col items-center">
                      <div className="mb-2 px-2 py-1 bg-cyan-500 bg-opacity-10 text-cyan-600 text-xs rounded-full">
                        Level 2
                      </div>
                      <TreeNodeComponent 
                        node={grandChild} 
                        isRoot={false}
                        isSmall={true}
                      />
                    </div>
                  ))}
                </div>
              ))}
            </div>
            
            {/* Level 3 - Only shown when expanded */}
            {showLevel3 && (
              <>
                {/* Connecting Lines from Level 2 to Level 3 */}
                <div className="flex justify-center w-full mb-2">
                  <div className="flex justify-between w-full px-6">
                    {currentTree.children.flatMap((child, childIndex) => 
                      child.children.map((grandChild, grandChildIndex) => (
                        <div key={`line-to-l3-${childIndex}-${grandChildIndex}`} className="flex flex-col items-center mx-2">
                          <div className="w-[2px] h-8 bg-gray-300"></div>
                          <div className="w-20 h-[2px] bg-gray-300 flex items-center justify-center">
                            <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
                          </div>
                          <div className="flex justify-between w-20">
                            <div className="w-[2px] h-8 bg-gray-300"></div>
                            <div className="w-[2px] h-8 bg-gray-300"></div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
                
                {/* Level 3 Nodes */}
                <div className="flex flex-wrap justify-center w-full px-4 mb-6 gap-2">
                  {currentTree.children.flatMap((child, childIndex) => 
                    child.children.flatMap((grandChild, grandChildIndex) => 
                      grandChild.children.map((greatGrandChild, greatGrandChildIndex) => (
                        <div key={`l3-${childIndex}-${grandChildIndex}-${greatGrandChildIndex}`} className="flex flex-col items-center mx-1">
                          <div className="mb-1 px-2 py-0.5 bg-pink-500 bg-opacity-10 text-pink-600 text-[10px] rounded-full">
                            Level 3
                          </div>
                          <TreeNodeComponent 
                            node={greatGrandChild} 
                            isRoot={false}
                            isSmall={true}
                          />
                        </div>
                      ))
                    )
                  )}
                </div>
              </>
            )}
            
            {/* Tree Legend */}
            <div className="flex justify-center space-x-4 mt-8 text-xs bg-white p-2 rounded-lg shadow-sm">
              <div className="flex items-center">
                <div className="h-3 w-3 rounded-full bg-primary mr-1"></div>
                <span>You</span>
              </div>
              <div className="flex items-center">
                <div className="h-3 w-3 rounded-full bg-cyan-500 mr-1"></div>
                <span>Active Member</span>
              </div>
              <div className="flex items-center">
                <div className="h-3 w-3 rounded-full bg-gray-200 mr-1"></div>
                <span>Pending/Empty</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}