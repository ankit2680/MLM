import { apiRequest } from "./queryClient";
import { TreeNode } from "@shared/schema";

// User API
export async function fetchUserTree(levels = 3): Promise<TreeNode | null> {
  const response = await apiRequest("GET", `/api/users/tree?levels=${levels}`);
  const data = await response.json();
  return data;
}

export async function fetchDirectRecruits() {
  return await apiRequest("GET", "/api/users/direct-recruits");
}

// Transaction API
export async function fetchTransactions() {
  return await apiRequest("GET", "/api/transactions");
}

// Withdrawal API
export async function requestWithdrawal(amount: number, bankDetails: any) {
  return await apiRequest("POST", "/api/withdrawals", {
    amount,
    bankDetails,
  });
}

export async function fetchWithdrawals(status?: string) {
  const url = status ? `/api/withdrawals?status=${status}` : "/api/withdrawals";
  return await apiRequest("GET", url);
}

// Admin API
export async function fetchAdminStats() {
  return await apiRequest("GET", "/api/admin/stats");
}

export async function fetchAllUsers() {
  return await apiRequest("GET", "/api/admin/users");
}

export async function processWithdrawal(id: number, status: 'approved' | 'rejected') {
  return await apiRequest("POST", `/api/admin/withdrawals/${id}/process`, {
    status,
  });
}

export async function generateTestData() {
  return await apiRequest("POST", "/api/admin/generate-test-data");
}
