import { TreeNode } from "@shared/schema";

// Get initials from a name
export function getInitials(name: string): string {
  return name
    .split(' ')
    .map(part => part.charAt(0).toUpperCase())
    .join('')
    .substring(0, 2);
}

// Utility function to calculate network size
export function calculateNetworkSize(tree: TreeNode | null): number {
  if (!tree) return 0;
  
  // Count current node if it's active
  let count = tree.isActive ? 1 : 0;
  
  // Recursively count children
  for (const child of tree.children) {
    count += calculateNetworkSize(child);
  }
  
  return count;
}

// Get counts for left and right branches
export function getBranchCounts(tree: TreeNode | null): { left: number, right: number } {
  if (!tree) return { left: 0, right: 0 };
  
  const leftBranch = tree.children.find(child => child.position === 'left');
  const rightBranch = tree.children.find(child => child.position === 'right');
  
  return {
    left: leftBranch ? calculateNetworkSize(leftBranch) : 0,
    right: rightBranch ? calculateNetworkSize(rightBranch) : 0
  };
}

// Get direct recruits count (level 1)
export function getDirectRecruits(tree: TreeNode | null): number {
  if (!tree) return 0;
  return tree.children.filter(child => child.isActive).length;
}

// Count members in levels 1-3
export function getLevels1to3Count(tree: TreeNode | null, currentLevel = 0): number {
  if (!tree) return 0;
  
  // Don't count the root node
  let count = currentLevel > 0 && currentLevel <= 3 && tree.isActive ? 1 : 0;
  
  // Only proceed if we're within levels 1-3
  if (currentLevel < 3) {
    for (const child of tree.children) {
      count += getLevels1to3Count(child, currentLevel + 1);
    }
  }
  
  return count;
}
