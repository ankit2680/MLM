import { 
  users, 
  transactions, 
  withdrawalRequests, 
  type User, 
  type InsertUser, 
  type Transaction, 
  type WithdrawalRequest,
  generateReferralId,
  getInitials
} from "@shared/schema";

// Storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  getUserByReferralId(referralId: string): Promise<User | undefined>;
  createUser(user: InsertUser, referredById?: number): Promise<User>;
  markUserPaymentComplete(id: number): Promise<User | undefined>;
  getUserDirectRecruits(userId: number): Promise<User[]>;
  getUserTree(userId: number, levels?: number): Promise<any>;
  getAllUsers(): Promise<User[]>;
  
  // Transaction methods
  getUserTransactions(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: Omit<Transaction, "id" | "createdAt" | "description"> & { description?: string }): Promise<Transaction>;
  
  // Withdrawal methods
  createWithdrawalRequest(withdrawal: Omit<WithdrawalRequest, "id" | "createdAt" | "processedAt" | "status">): Promise<WithdrawalRequest>;
  getWithdrawalRequests(status?: string): Promise<WithdrawalRequest[]>;
  processWithdrawalRequest(id: number, status: 'approved' | 'rejected'): Promise<WithdrawalRequest | undefined>;
  
  // Admin methods
  getAdminStats(): Promise<any>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private transactions: Map<number, Transaction>;
  private withdrawalRequests: Map<number, WithdrawalRequest>;
  private userCounter: number;
  private transactionCounter: number;
  private withdrawalCounter: number;

  constructor() {
    this.users = new Map();
    this.transactions = new Map();
    this.withdrawalRequests = new Map();
    this.userCounter = 1;
    this.transactionCounter = 1;
    this.withdrawalCounter = 1;
    
    // Create an admin user
    this.createAdminUser();
  }

  private createAdminUser() {
    const admin: User = {
      id: this.userCounter++,
      username: 'admin',
      password: 'admin123', // In real app, this would be hashed
      name: 'Admin User',
      phone: '9999999999',
      referralId: generateReferralId(),
      referredBy: null,
      parentId: null,
      position: null,
      registrationFee: 0,
      feePaid: true,
      wallet: 0,
      joinedAt: new Date(),
      isAdmin: true
    };
    this.users.set(admin.id, admin);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.phone === phone);
  }

  async getUserByReferralId(referralId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.referralId === referralId);
  }

  async createUser(userInput: InsertUser, referredById?: number): Promise<User> {
    // Generate unique referral ID
    const referralId = generateReferralId();
    
    // Check if referrer exists and place user in binary tree
    let parentId = null;
    let position = null;
    
    if (referredById) {
      // Get the referrer user
      const referrer = await this.getUser(referredById);
      if (!referrer) {
        throw new Error("Referrer not found");
      }
      
      // Find a place in the binary tree
      const { parent, pos } = await this.findPlaceInTree(referredById);
      if (!parent || !pos) {
        throw new Error("No available position in the binary tree");
      }
      
      parentId = parent;
      position = pos;
    }
    
    // Create the user
    const id = this.userCounter++;
    const user: User = {
      id,
      username: userInput.username,
      password: userInput.password, // In real app, this would be hashed
      name: userInput.name,
      phone: userInput.phone,
      referralId,
      referredBy: referredById || null,
      parentId,
      position,
      registrationFee: 4, // Fixed registration fee
      feePaid: false,
      wallet: 0,
      joinedAt: new Date(),
      isAdmin: false
    };
    
    this.users.set(id, user);
    return user;
  }

  async markUserPaymentComplete(id: number): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) {
      return undefined;
    }
    
    user.feePaid = true;
    this.users.set(id, user);
    
    // Create registration transaction
    await this.createTransaction({
      userId: id,
      type: 'registration',
      amount: -4, // Negative amount because user is paying
      source: 'registration',
      status: 'completed',
      description: 'Registration fee payment'
    });
    
    // Process multi-level commissions based on the new reward scheme
    await this.processMultiLevelCommissions(id);
    
    return user;
  }

  private async findPlaceInTree(rootId: number): Promise<{ parent: number | null, pos: string | null }> {
    // BFS to find first node with an available position
    const queue: number[] = [rootId];
    const visited = new Set<number>();
    
    while (queue.length > 0) {
      const currentId = queue.shift()!;
      if (visited.has(currentId)) continue;
      visited.add(currentId);
      
      const currentUser = await this.getUser(currentId);
      if (!currentUser) continue;
      
      // Check for users with this parent
      const children = Array.from(this.users.values())
        .filter(u => u.parentId === currentId);
      
      // Check if left position is available
      const hasLeft = children.some(c => c.position === 'left');
      if (!hasLeft) {
        return { parent: currentId, pos: 'left' };
      }
      
      // Check if right position is available
      const hasRight = children.some(c => c.position === 'right');
      if (!hasRight) {
        return { parent: currentId, pos: 'right' };
      }
      
      // Add children to queue
      children.forEach(child => queue.push(child.id));
    }
    
    return { parent: null, pos: null }; // No available position
  }

  private async getAncestorsPath(userId: number, maxLevels = 10): Promise<number[]> {
    const path: number[] = [];
    let currentUser = await this.getUser(userId);
    let level = 0;
    
    while (currentUser && currentUser.parentId && level < maxLevels) {
      path.push(currentUser.parentId);
      currentUser = await this.getUser(currentUser.parentId);
      level++;
    }
    
    return path;
  }

  private async processMultiLevelCommissions(newUserId: number): Promise<void> {
    // Get ancestors up to 10 levels for deep commission distribution
    const ancestors = await this.getAncestorsPath(newUserId, 10);
    
    // Process commissions at each level per the new reward scheme
    for (let i = 0; i < ancestors.length; i++) {
      const ancestorId = ancestors[i];
      const ancestor = await this.getUser(ancestorId);
      
      if (!ancestor) continue;
      
      // Determine commission amount based on level in the tree
      let commissionAmount = 0;
      let levelLabel = '';
      
      if (i === 0) {
        // Direct referral (Level 1) - No direct commission for Level 1
        commissionAmount = 0;
        levelLabel = 'direct referral';
      } else if (i === 1) {
        // Level 2 - A gets ₹4 when B and C complete their referrals (D,E and F,G)
        // Check if the referrals of this person's direct referrals are completing
        const userReferrals = await this.getUserDirectRecruits(ancestorId);
        
        // Need to check if at least two of user's referrals have their own recruits
        let referralsWithOwnRecruits = 0;
        for (const referral of userReferrals) {
          const referralRecruits = await this.getUserDirectRecruits(referral.id);
          if (referralRecruits.length >= 2) {
            referralsWithOwnRecruits++;
          }
        }
        
        // If at least 2 of the level 1 referrals have completed their binary (have 2 recruits each)
        if (referralsWithOwnRecruits >= 2) {
          commissionAmount = 4;
          levelLabel = 'level 2 completion';
        }
      } else {
        // Level 3+ - All upline members get ₹1 for each deeper level completion
        commissionAmount = 1;
        levelLabel = `level ${i+1} completion`;
      }
      
      if (commissionAmount > 0 && ancestor.wallet !== null) {
        // Update wallet
        ancestor.wallet += commissionAmount;
        this.users.set(ancestorId, ancestor);
        
        // Create commission transaction
        await this.createTransaction({
          userId: ancestorId,
          type: 'commission',
          amount: commissionAmount,
          source: `${levelLabel}:${newUserId}`,
          status: 'completed',
          description: `Commission of ₹${commissionAmount} for ${levelLabel}`
        });
      }
    }
  }

  async getUserDirectRecruits(userId: number): Promise<User[]> {
    return Array.from(this.users.values())
      .filter(user => user.referredBy === userId);
  }

  async getUserTree(userId: number, levels = 3): Promise<any> {
    const root = await this.getUser(userId);
    if (!root) return null;
    
    // Recursive function to build tree
    const buildTree = async (nodeId: number, level: number): Promise<any> => {
      if (level > levels) return null;
      
      const user = await this.getUser(nodeId);
      if (!user) return null;
      
      // Get immediate children
      const children = Array.from(this.users.values())
        .filter(u => u.parentId === nodeId);
      
      const leftChild = children.find(c => c.position === 'left');
      const rightChild = children.find(c => c.position === 'right');
      
      // Build tree node
      const node = {
        id: user.id,
        name: user.name,
        initials: getInitials(user.name),
        referralId: user.referralId,
        position: user.position,
        isActive: user.feePaid,
        children: []
      };
      
      // Add children recursively
      if (leftChild) {
        const leftNode = await buildTree(leftChild.id, level + 1);
        if (leftNode) node.children.push(leftNode);
      } else if (level < levels) {
        // Add empty placeholder for left
        node.children.push({
          id: -1,
          name: '',
          initials: '',
          referralId: '',
          position: 'left',
          isActive: false,
          children: []
        });
      }
      
      if (rightChild) {
        const rightNode = await buildTree(rightChild.id, level + 1);
        if (rightNode) node.children.push(rightNode);
      } else if (level < levels) {
        // Add empty placeholder for right
        node.children.push({
          id: -2,
          name: '',
          initials: '',
          referralId: '',
          position: 'right',
          isActive: false,
          children: []
        });
      }
      
      return node;
    };
    
    return buildTree(userId, 0);
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getUserTransactions(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter(tx => tx.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createTransaction(transaction: Omit<Transaction, "id" | "createdAt" | "description"> & { description?: string }): Promise<Transaction> {
    const id = this.transactionCounter++;
    const newTransaction: Transaction = {
      ...transaction,
      id,
      createdAt: new Date(),
      description: transaction.description || null
    };
    
    this.transactions.set(id, newTransaction);
    return newTransaction;
  }

  async createWithdrawalRequest(withdrawal: Omit<WithdrawalRequest, "id" | "createdAt" | "processedAt" | "status">): Promise<WithdrawalRequest> {
    // Check if user has enough balance
    const user = await this.getUser(withdrawal.userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    // Check if withdrawal amount meets minimum requirement (20 Rs)
    if (withdrawal.amount < 20) {
      throw new Error("Minimum withdrawal amount is 20 Rs");
    }
    
    if (user.wallet !== null && user.wallet < withdrawal.amount) {
      throw new Error("Insufficient balance");
    }
    
    // Create withdrawal request
    const id = this.withdrawalCounter++;
    const request: WithdrawalRequest = {
      ...withdrawal,
      id,
      status: 'pending',
      createdAt: new Date(),
      processedAt: null
    };
    
    this.withdrawalRequests.set(id, request);
    return request;
  }

  async getWithdrawalRequests(status?: string): Promise<WithdrawalRequest[]> {
    let requests = Array.from(this.withdrawalRequests.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    if (status) {
      requests = requests.filter(r => r.status === status);
    }
    
    return requests;
  }

  async processWithdrawalRequest(id: number, status: 'approved' | 'rejected'): Promise<WithdrawalRequest | undefined> {
    const request = this.withdrawalRequests.get(id);
    if (!request) {
      return undefined;
    }
    
    request.status = status;
    request.processedAt = new Date();
    this.withdrawalRequests.set(id, request);
    
    if (status === 'approved') {
      // Update user wallet and create transaction
      const user = await this.getUser(request.userId);
      if (user) {
        user.wallet -= request.amount;
        this.users.set(user.id, user);
        
        await this.createTransaction({
          userId: user.id,
          type: 'withdrawal',
          amount: -request.amount, // Negative amount for withdrawal
          source: 'bank',
          status: 'completed',
          description: `Withdrawal of ₹${request.amount} to bank account`
        });
      }
    }
    
    return request;
  }

  async getAdminStats(): Promise<any> {
    const allUsers = await this.getAllUsers();
    const regularUsers = allUsers.filter(u => !u.isAdmin);
    
    return {
      totalUsers: regularUsers.length,
      activeUsers: regularUsers.filter(u => u.feePaid).length,
      totalRegistrationFees: regularUsers.filter(u => u.feePaid).length * 4,
      totalCommissionsPaid: Array.from(this.transactions.values())
        .filter(tx => tx.type === 'commission')
        .reduce((sum, tx) => sum + tx.amount, 0),
      pendingWithdrawals: (await this.getWithdrawalRequests('pending')).length,
      recentJoins: regularUsers
        .sort((a, b) => new Date(b.joinedAt).getTime() - new Date(a.joinedAt).getTime())
        .slice(0, 5)
    };
  }
}

export const storage = new MemStorage();
