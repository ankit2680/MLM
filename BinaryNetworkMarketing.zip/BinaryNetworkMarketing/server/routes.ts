import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginSchema, insertUserSchema, insertTransactionSchema, insertWithdrawalRequestSchema } from "@shared/schema";
import session from "express-session";
import { ZodError } from "zod";
import MemoryStore from "memorystore";

const SessionStore = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Session setup
  app.use(
    session({
      cookie: { maxAge: 86400000 }, // 24 hours
      store: new SessionStore({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      resave: false,
      saveUninitialized: false,
      secret: process.env.SESSION_SECRET || "binarygrowth-secret",
    })
  );

  // Add auth middleware
  const isAuthenticated = (req: Request, res: Response, next: Function) => {
    if (req.session && req.session.userId) {
      return next();
    }
    return res.status(401).json({ message: "Unauthorized" });
  };

  const isAdmin = async (req: Request, res: Response, next: Function) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user || !user.isAdmin) {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    return next();
  };

  // Error handling middleware
  const handleErrors = (fn: Function) => async (req: Request, res: Response) => {
    try {
      await fn(req, res);
    } catch (error) {
      console.error(error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      
      if (error instanceof Error) {
        return res.status(400).json({ message: error.message });
      }
      
      res.status(500).json({ message: "Internal server error" });
    }
  };

  // AUTH ROUTES
  app.post("/api/auth/login", handleErrors(async (req: Request, res: Response) => {
    const data = loginSchema.parse(req.body);
    
    const user = await storage.getUserByPhone(data.phone);
    if (!user || user.password !== data.password) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    
    // Set session
    req.session.userId = user.id;
    req.session.isAdmin = user.isAdmin;
    
    return res.json({
      id: user.id,
      name: user.name,
      phone: user.phone,
      referralId: user.referralId,
      isAdmin: user.isAdmin,
      feePaid: user.feePaid
    });
  }));

  app.post("/api/auth/register", handleErrors(async (req: Request, res: Response) => {
    const data = insertUserSchema.parse(req.body);
    
    // Check if referral code is valid
    const referrer = await storage.getUserByReferralId(data.referralCode);
    if (!referrer) {
      return res.status(400).json({ message: "Invalid referral code" });
    }
    
    // Check if phone is already registered
    const existingUser = await storage.getUserByPhone(data.phone);
    if (existingUser) {
      return res.status(400).json({ message: "Phone number already registered" });
    }
    
    // Create user
    const user = await storage.createUser({
      username: data.username,
      password: data.password,
      name: data.name,
      phone: data.phone,
      referredBy: referrer.id,
      parentId: null,
      position: null
    }, referrer.id);
    
    return res.status(201).json({
      id: user.id,
      name: user.name,
      phone: user.phone,
      referralId: user.referralId
    });
  }));

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.session.destroy(() => {
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", isAuthenticated, handleErrors(async (req: Request, res: Response) => {
    const user = await storage.getUser(req.session.userId!);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    return res.json({
      id: user.id,
      name: user.name,
      phone: user.phone,
      referralId: user.referralId,
      wallet: user.wallet,
      isAdmin: user.isAdmin,
      feePaid: user.feePaid,
      joinedAt: user.joinedAt
    });
  }));

  // PAYMENT ROUTES
  app.post("/api/payments/complete", isAuthenticated, handleErrors(async (req: Request, res: Response) => {
    const userId = req.session.userId!;
    
    // In a real app, we would process actual payment info
    // For now, we'll just mark the payment as complete
    const updatedUser = await storage.markUserPaymentComplete(userId);
    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }
    
    return res.json({ 
      message: "Payment completed successfully",
      feePaid: true
    });
  }));

  // USER ROUTES
  app.get("/api/users/tree", isAuthenticated, handleErrors(async (req: Request, res: Response) => {
    const userId = req.session.userId!;
    const levels = req.query.levels ? parseInt(req.query.levels as string) : 3;
    const maxLevel = Math.min(levels, 8); // Limit to 8 levels to prevent performance issues
    
    const tree = await storage.getUserTree(userId, maxLevel);
    return res.json(tree);
  }));

  app.get("/api/users/direct-recruits", isAuthenticated, handleErrors(async (req: Request, res: Response) => {
    const userId = req.session.userId!;
    
    const recruits = await storage.getUserDirectRecruits(userId);
    return res.json(recruits.map(u => ({
      id: u.id,
      name: u.name,
      referralId: u.referralId,
      position: u.position,
      joinedAt: u.joinedAt
    })));
  }));

  // TRANSACTION ROUTES
  app.get("/api/transactions", isAuthenticated, handleErrors(async (req: Request, res: Response) => {
    const userId = req.session.userId!;
    
    const transactions = await storage.getUserTransactions(userId);
    return res.json(transactions);
  }));

  // WITHDRAWAL ROUTES
  app.post("/api/withdrawals", isAuthenticated, handleErrors(async (req: Request, res: Response) => {
    const userId = req.session.userId!;
    
    const withdrawalData = insertWithdrawalRequestSchema.parse({
      ...req.body,
      userId
    });
    
    const withdrawal = await storage.createWithdrawalRequest(withdrawalData);
    return res.status(201).json(withdrawal);
  }));

  app.get("/api/withdrawals", isAuthenticated, handleErrors(async (req: Request, res: Response) => {
    const userId = req.session.userId!;
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Only admin can see all withdrawals, regular users see their own
    let withdrawals;
    if (user.isAdmin) {
      const status = req.query.status as string | undefined;
      withdrawals = await storage.getWithdrawalRequests(status);
    } else {
      // Filter withdrawals for just this user - would need additional storage method
      // For now, just return empty array for non-admin users
      withdrawals = [];
    }
    
    return res.json(withdrawals);
  }));

  // ADMIN ROUTES
  app.get("/api/admin/stats", isAdmin, handleErrors(async (req: Request, res: Response) => {
    const stats = await storage.getAdminStats();
    return res.json(stats);
  }));

  app.get("/api/admin/users", isAdmin, handleErrors(async (req: Request, res: Response) => {
    const users = await storage.getAllUsers();
    return res.json(users.map(u => ({
      id: u.id,
      name: u.name,
      phone: u.phone,
      referralId: u.referralId,
      feePaid: u.feePaid,
      wallet: u.wallet,
      joinedAt: u.joinedAt,
      isAdmin: u.isAdmin
    })));
  }));
  
  // Development endpoint to generate test data
  app.post("/api/admin/generate-test-data", isAdmin, handleErrors(async (req: Request, res: Response) => {
    // Generate test users
    const admin = await storage.getUserByPhone("9999999999");
    if (!admin) {
      return res.status(404).json({ message: "Admin user not found" });
    }
    
    // Level 1 - Admin's direct referrals (2)
    const user1 = await storage.createUser({
      username: "user1",
      password: "password123",
      name: "John Smith",
      phone: "1111111111",
      referralId: "",
      referredBy: admin.id
    }, admin.id);
    
    const user2 = await storage.createUser({
      username: "user2",
      password: "password123",
      name: "Jane Doe",
      phone: "2222222222",
      referralId: "",
      referredBy: admin.id
    }, admin.id);
    
    // Level 2 - User1's direct referrals (2)
    const user3 = await storage.createUser({
      username: "user3",
      password: "password123",
      name: "Bob Johnson",
      phone: "3333333333",
      referralId: "",
      referredBy: user1.id
    }, user1.id);
    
    const user4 = await storage.createUser({
      username: "user4",
      password: "password123",
      name: "Alice Brown",
      phone: "4444444444",
      referralId: "",
      referredBy: user1.id
    }, user1.id);
    
    // Level 2 - User2's direct referrals (2)
    const user5 = await storage.createUser({
      username: "user5",
      password: "password123",
      name: "Charlie Davis",
      phone: "5555555555",
      referralId: "",
      referredBy: user2.id
    }, user2.id);
    
    const user6 = await storage.createUser({
      username: "user6",
      password: "password123",
      name: "Diana Wilson",
      phone: "6666666666",
      referralId: "",
      referredBy: user2.id
    }, user2.id);
    
    // Mark all users as having paid fee
    await storage.markUserPaymentComplete(user1.id);
    await storage.markUserPaymentComplete(user2.id);
    await storage.markUserPaymentComplete(user3.id);
    await storage.markUserPaymentComplete(user4.id);
    await storage.markUserPaymentComplete(user5.id);
    await storage.markUserPaymentComplete(user6.id);
    
    // Generate some transactions
    await storage.createTransaction({
      userId: admin.id,
      amount: 4,
      type: "commission",
      source: "Third row payout",
      status: "completed"
    });
    
    await storage.createTransaction({
      userId: user1.id,
      amount: 2,
      type: "commission",
      source: "Third row payout",
      status: "completed"
    });
    
    await storage.createTransaction({
      userId: user2.id,
      amount: 2,
      type: "commission",
      source: "Third row payout",
      status: "completed"
    });
    
    return res.json({ 
      message: "Test data generated successfully",
      users: [user1, user2, user3, user4, user5, user6]
    });
  }));

  app.post("/api/admin/withdrawals/:id/process", isAdmin, handleErrors(async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    const status = req.body.status as 'approved' | 'rejected';
    
    if (status !== 'approved' && status !== 'rejected') {
      return res.status(400).json({ message: "Invalid status" });
    }
    
    const withdrawal = await storage.processWithdrawalRequest(id, status);
    if (!withdrawal) {
      return res.status(404).json({ message: "Withdrawal request not found" });
    }
    
    return res.json(withdrawal);
  }));

  const httpServer = createServer(app);
  return httpServer;
}
